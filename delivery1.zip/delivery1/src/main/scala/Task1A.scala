object Task1A extends App {
    var arr:Array[Int] = new Array[Int](50)
    for (i <- 1 to 50) {
        arr(i-1) = i
    }
}
