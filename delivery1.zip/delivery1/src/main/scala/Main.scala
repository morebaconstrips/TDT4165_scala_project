object Main extends App {
  println("Hello World");
}
